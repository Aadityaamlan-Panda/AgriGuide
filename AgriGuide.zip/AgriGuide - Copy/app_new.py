import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# Machine Learning Libraries
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, IsolationForest
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score, classification_report, confusion_matrix

# For the GUI
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

# ----------------------------
# Step 1: Data Loading and Preprocessing
# ----------------------------
# (Adjust file paths as needed)
rainfall_file = 'rainfall_data.csv'
temperature_file = 'temperature_data.csv'

rainfall_df = pd.read_csv(rainfall_file)
temperature_df = pd.read_csv(temperature_file)

# Convert YEAR columns to numeric
rainfall_df['YEAR'] = pd.to_numeric(rainfall_df['YEAR'], errors='coerce')
temperature_df['YEAR'] = pd.to_numeric(temperature_df['YEAR'], errors='coerce')

# Merge datasets on YEAR and, if available, SUBDIVISION
if 'SUBDIVISION' in rainfall_df.columns and 'SUBDIVISION' in temperature_df.columns:
    merged_df = pd.merge(rainfall_df, temperature_df, on=['SUBDIVISION', 'YEAR'], suffixes=('_rain', '_temp'))
else:
    merged_df = pd.merge(rainfall_df, temperature_df, on='YEAR', suffixes=('_rain', '_temp'))

# Convert expected numeric columns
numeric_columns = [
    'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',
    'ANNUAL', 'JF', 'MAM', 'JJAS', 'OND',      # Rainfall-related
    'ANNUAL_temp', 'JAN-FEB', 'MAR-MAY', 'JUN-SEP', 'OCT-DEC'  # Temperature-related
]
for col in numeric_columns:
    if col in merged_df.columns:
        merged_df[col] = pd.to_numeric(merged_df[col], errors='coerce')

# Fill missing numeric values with the column mean
num_cols = merged_df.select_dtypes(include=[np.number]).columns
merged_df[num_cols] = merged_df[num_cols].fillna(merged_df[num_cols].mean())

# ----------------------------
# Step 2: Define Functions for EDA and Modeling
# ----------------------------
def create_eda_figure(df, sub_name):
    """
    Creates and returns a matplotlib Figure with multi-panel EDA for the given subdivision.
    """
    n_panels = 2  # always include annual rainfall and temperature
    if 'JJAS' in df.columns:
        n_panels += 1
    if 'JUN-SEP' in df.columns:
        n_panels += 1

    fig, axes = plt.subplots(n_panels, 1, figsize=(8, 3*n_panels))
    fig.suptitle(f'EDA for {sub_name}', fontsize=14)
    panel_idx = 0

    # Annual Rainfall
    axes[panel_idx].plot(df['YEAR'], df['ANNUAL_rain'], marker='o', color='b')
    axes[panel_idx].set_title('Annual Rainfall Trend')
    axes[panel_idx].set_xlabel('Year')
    axes[panel_idx].set_ylabel('Rainfall (mm)')
    axes[panel_idx].grid(True)
    panel_idx += 1

    # Annual Temperature
    axes[panel_idx].plot(df['YEAR'], df['ANNUAL_temp'], marker='o', color='r')
    axes[panel_idx].set_title('Annual Temperature Trend')
    axes[panel_idx].set_xlabel('Year')
    axes[panel_idx].set_ylabel('Temperature (°C)')
    axes[panel_idx].grid(True)
    panel_idx += 1

    # Seasonal Rainfall (JJAS) if exists
    if 'JJAS' in df.columns:
        axes[panel_idx].plot(df['YEAR'], df['JJAS'], marker='o', color='g')
        axes[panel_idx].set_title('Monsoon Rainfall (JJAS) Trend')
        axes[panel_idx].set_xlabel('Year')
        axes[panel_idx].set_ylabel('Rainfall (mm)')
        axes[panel_idx].grid(True)
        panel_idx += 1

    # Seasonal Temperature (JUN-SEP) if exists
    if 'JUN-SEP' in df.columns:
        axes[panel_idx].plot(df['YEAR'], df['JUN-SEP'], marker='o', color='m')
        axes[panel_idx].set_title('Monsoon Temperature (JUN-SEP) Trend')
        axes[panel_idx].set_xlabel('Year')
        axes[panel_idx].set_ylabel('Temperature (°C)')
        axes[panel_idx].grid(True)
    
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    return fig

def regression_forecast(df):
    """
    Performs regression forecasting for Annual Rainfall using a RandomForestRegressor.
    """
    features = ['YEAR']
    for col in ['MAM', 'JJAS', 'OND']:
        if col in df.columns:
            features.append(col)
    X = df[features]
    y = df['ANNUAL_rain']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    rf = RandomForestRegressor(random_state=42)
    param_grid = {'n_estimators': [50, 100, 200], 'max_depth': [None, 5, 10]}
    grid = GridSearchCV(rf, param_grid, cv=3, scoring='neg_mean_squared_error')
    grid.fit(X_train, y_train)
    best_rf = grid.best_estimator_
    y_pred = best_rf.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    # Forecast next year's rainfall
    next_year = df['YEAR'].max() + 1
    next_feat = {'YEAR': next_year}
    for feat in features:
        if feat != 'YEAR':
            next_feat[feat] = df[feat].mean()
    next_df = pd.DataFrame([next_feat])
    forecast = best_rf.predict(next_df)[0]

    result = (f"Regression Forecast for {df.iloc[0]['SUBDIVISION'] if 'SUBDIVISION' in df.columns else 'National'}:\n"
              f"Test MSE: {mse:.2f}, R²: {r2:.2f}\n"
              f"Predicted Annual Rainfall for year {next_year}: {forecast:.2f} mm")
    return result

def get_classification_report():
    """
    Trains a RandomForestClassifier on the full merged_df and returns the classification report.
    """
    threshold_rain = merged_df['ANNUAL_rain'].quantile(0.25)
    threshold_temp = merged_df['ANNUAL_temp'].quantile(0.75)
    merged_df['Risk'] = np.where(
        (merged_df['ANNUAL_rain'] < threshold_rain) & (merged_df['ANNUAL_temp'] > threshold_temp),
        'High Risk', 'Low Risk'
    )

    features = ['YEAR', 'ANNUAL_temp']
    for col in ['MAM', 'JJAS', 'OND']:
        if col in merged_df.columns:
            features.append(col)
    X = merged_df[features]
    y = merged_df['Risk']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = RandomForestClassifier(random_state=42)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    report = classification_report(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)
    result = f"Classification Report:\n{report}\nConfusion Matrix:\n{cm}"
    return result

def get_anomaly_info(subdivision):
    """
    Performs anomaly detection on the data for the selected subdivision and returns a string summary.
    """
    # Filter data for the selected subdivision
    if 'SUBDIVISION' in merged_df.columns:
        df = merged_df[merged_df['SUBDIVISION'] == subdivision].copy()
    else:
        df = merged_df.copy()

    # Perform anomaly detection
    features = df[['ANNUAL_rain', 'ANNUAL_temp']]
    iso = IsolationForest(contamination=0.05, random_state=42)
    df['anomaly'] = iso.fit_predict(features)
    anomalies = df[df['anomaly'] == -1]

    # Prepare the anomaly info string
    if 'SUBDIVISION' in anomalies.columns:
        info = anomalies[['YEAR', 'SUBDIVISION', 'ANNUAL_rain', 'ANNUAL_temp']].to_string(index=False)
    else:
        info = anomalies[['YEAR', 'ANNUAL_rain', 'ANNUAL_temp']].to_string(index=False)
    
    return info
# ----------------------------
# Step 3: Build the GUI using Tkinter
# ----------------------------
class ClimateAnalysisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Climate Analysis GUI")
        self.root.geometry("1000x800")

        # Create a Notebook (tabbed interface)
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # Create frames for each tab
        self.analysis_frame = ttk.Frame(self.notebook)
        self.report_frame = ttk.Frame(self.notebook)
        self.settings_frame = ttk.Frame(self.notebook)

        self.notebook.add(self.analysis_frame, text="Analysis")
        self.notebook.add(self.report_frame, text="Reports")
        self.notebook.add(self.settings_frame, text="Settings")

        # Analysis Tab
        self.setup_analysis_tab()
        # Reports Tab
        self.setup_report_tab()
        # Settings Tab
        self.setup_settings_tab()

    def setup_analysis_tab(self):
        # Frame for Controls
        control_frame = ttk.Frame(self.analysis_frame)
        control_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

        # Label and Dropdown for Subdivision selection
        ttk.Label(control_frame, text="Select Subdivision:").pack(side=tk.LEFT, padx=5)

        if 'SUBDIVISION' in merged_df.columns:
            sub_options = list(merged_df['SUBDIVISION'].unique())
        else:
            sub_options = ["National"]

        self.selected_sub = tk.StringVar(value=sub_options[0])
        sub_dropdown = ttk.Combobox(control_frame, textvariable=self.selected_sub, values=sub_options, state="readonly")
        sub_dropdown.pack(side=tk.LEFT, padx=5)

        # Buttons for actions
        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_frame, text="Show EDA", command=self.show_eda).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(btn_frame, text="Regression Forecast", command=self.show_regression).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(btn_frame, text="Classification Report", command=self.show_classification).grid(row=0, column=2, padx=5, pady=5)
        ttk.Button(btn_frame, text="Anomaly Detection", command=self.show_anomalies).grid(row=0, column=3, padx=5, pady=5)

        # A frame for embedding matplotlib figures
        self.plot_frame = ttk.Frame(self.analysis_frame)
        self.plot_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=10)

        # A scrolled text widget to show textual outputs
        self.output_text = scrolledtext.ScrolledText(self.analysis_frame, width=100, height=10)
        self.output_text.pack(side=tk.BOTTOM, padx=10, pady=10)

    def setup_report_tab(self):
        # Add a button to save reports
        ttk.Button(self.report_frame, text="Save Report", command=self.save_report).pack(padx=10, pady=10)

    def setup_settings_tab(self):
        # Add settings options here
        ttk.Label(self.settings_frame, text="Settings will be added here").pack(padx=10, pady=10)

    def clear_plot(self):
        if hasattr(self, 'canvas'):
            self.canvas.get_tk_widget().destroy()
            del self.canvas

    def show_eda(self):
        self.clear_plot()
        sub = self.selected_sub.get()
        if 'SUBDIVISION' in merged_df.columns:
            df_plot = merged_df[merged_df['SUBDIVISION'] == sub].copy()
        else:
            df_plot = merged_df.copy()
        fig = create_eda_figure(df_plot, sub)
        self.canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Add a toolbar for the plot
        toolbar = NavigationToolbar2Tk(self.canvas, self.plot_frame)
        toolbar.update()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def show_regression(self):
        self.clear_plot()
        sub = self.selected_sub.get()
        if 'SUBDIVISION' in merged_df.columns:
            df_demo = merged_df[merged_df['SUBDIVISION'] == sub].copy()
        else:
            df_demo = merged_df.copy()
        result = regression_forecast(df_demo)
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, result)

    def show_classification(self):
        self.clear_plot()
        result = get_classification_report()
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, result)

    def show_anomalies(self):
        self.clear_plot()
        sub = self.selected_sub.get()  # Get the selected subdivision
        info = get_anomaly_info(sub)   # Pass the subdivision to the function
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, f"Anomalies Detected for {sub}:\n{info}")

    def save_report(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, 'w') as file:
                file.write(self.output_text.get(1.0, tk.END))
            messagebox.showinfo("Save Report", "Report saved successfully!")

# Run the GUI
if __name__ == "__main__":
    root = tk.Tk()
    app = ClimateAnalysisApp(root)
    root.mainloop()