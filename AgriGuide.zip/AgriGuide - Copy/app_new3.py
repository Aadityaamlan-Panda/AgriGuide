import sys
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings("ignore")

# Machine Learning Libraries
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, IsolationForest
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score, classification_report, confusion_matrix

# ----------------------------
# Data Loading and Preprocessing
# ----------------------------
rainfall_file = 'rainfall_data.csv'
temperature_file = 'temperature_data.csv'

rainfall_df = pd.read_csv(rainfall_file)
temperature_df = pd.read_csv(temperature_file)

# Convert YEAR columns to numeric
rainfall_df['YEAR'] = pd.to_numeric(rainfall_df['YEAR'], errors='coerce')
temperature_df['YEAR'] = pd.to_numeric(temperature_df['YEAR'], errors='coerce')

# Merge datasets on YEAR and, if available, SUBDIVISION
if 'SUBDIVISION' in rainfall_df.columns and 'SUBDIVISION' in temperature_df.columns:
    merged_df = pd.merge(rainfall_df, temperature_df, on=['SUBDIVISION', 'YEAR'], suffixes=('_rain', '_temp'))
else:
    merged_df = pd.merge(rainfall_df, temperature_df, on='YEAR', suffixes=('_rain', '_temp'))

# Convert expected numeric columns
numeric_columns = [
    'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',
    'ANNUAL', 'JF', 'MAM', 'JJAS', 'OND',      # Rainfall-related
    'ANNUAL_temp', 'JAN-FEB', 'MAR-MAY', 'JUN-SEP', 'OCT-DEC'  # Temperature-related
]
for col in numeric_columns:
    if col in merged_df.columns:
        merged_df[col] = pd.to_numeric(merged_df[col], errors='coerce')

# Fill missing numeric values with the column mean
num_cols = merged_df.select_dtypes(include=[np.number]).columns
merged_df[num_cols] = merged_df[num_cols].fillna(merged_df[num_cols].mean())
print(merged_df.columns)

# ----------------------------
# Functions for EDA, Modeling, Forecasting, and AI Recommendations
# ----------------------------
def create_eda_figure(df, sub_name):
    """
    Creates and returns a matplotlib Figure with multi-panel EDA for the given subdivision.
    """
    n_panels = 2  # Annual rainfall and temperature
    if 'JJAS' in df.columns:
        n_panels += 1
    if 'JUN-SEP' in df.columns:
        n_panels += 1

    fig, axes = plt.subplots(n_panels, 1, figsize=(8, 3*n_panels))
    fig.suptitle(f'EDA for {sub_name}', fontsize=14)
    panel_idx = 0

    # Annual Rainfall
    axes[panel_idx].plot(df['YEAR'], df['ANNUAL_rain'], marker='o', color='b')
    axes[panel_idx].set_title('Annual Rainfall Trend')
    axes[panel_idx].set_xlabel('Year')
    axes[panel_idx].set_ylabel('Rainfall (mm)')
    axes[panel_idx].grid(True)
    panel_idx += 1

    # Annual Temperature
    axes[panel_idx].plot(df['YEAR'], df['ANNUAL_temp'], marker='o', color='r')
    axes[panel_idx].set_title('Annual Temperature Trend')
    axes[panel_idx].set_xlabel('Year')
    axes[panel_idx].set_ylabel('Temperature (°C)')
    axes[panel_idx].grid(True)
    panel_idx += 1

    # Seasonal Rainfall (JJAS) if exists
    if 'JJAS' in df.columns:
        axes[panel_idx].plot(df['YEAR'], df['JJAS'], marker='o', color='g')
        axes[panel_idx].set_title('Monsoon Rainfall (JJAS) Trend')
        axes[panel_idx].set_xlabel('Year')
        axes[panel_idx].set_ylabel('Rainfall (mm)')
        axes[panel_idx].grid(True)
        panel_idx += 1

    # Seasonal Temperature (JUN-SEP) if exists
    if 'JUN-SEP' in df.columns:
        axes[panel_idx].plot(df['YEAR'], df['JUN-SEP'], marker='o', color='m')
        axes[panel_idx].set_title('Monsoon Temperature (JUN-SEP) Trend')
        axes[panel_idx].set_xlabel('Year')
        axes[panel_idx].set_ylabel('Temperature (°C)')
        axes[panel_idx].grid(True)
    
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    return fig

def regression_forecast(df):
    """
    Performs regression forecasting for Annual Rainfall using a RandomForestRegressor
    and predicts for the next year only.
    """
    features = ['YEAR']
    for col in ['MAM', 'JJAS', 'OND']:
        if col in df.columns:
            features.append(col)
    X = df[features]
    y = df['ANNUAL_rain']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    rf = RandomForestRegressor(random_state=42)
    param_grid = {'n_estimators': [50, 100, 200], 'max_depth': [None, 5, 10]}
    grid = GridSearchCV(rf, param_grid, cv=3, scoring='neg_mean_squared_error')
    grid.fit(X_train, y_train)
    best_rf = grid.best_estimator_
    y_pred = best_rf.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    # Forecast next year's rainfall
    next_year = df['YEAR'].max() + 1
    next_feat = {'YEAR': next_year}
    for feat in features:
        if feat != 'YEAR':
            next_feat[feat] = df[feat].mean()
    next_df = pd.DataFrame([next_feat])
    forecast = best_rf.predict(next_df)[0]

    result = (f"Regression Forecast for {df.iloc[0]['SUBDIVISION'] if 'SUBDIVISION' in df.columns else 'National'}:\n"
              f"Test MSE: {mse:.2f}, R²: {r2:.2f}\n"
              f"Predicted Annual Rainfall for year {next_year}: {forecast:.2f} mm")
    return result

def forecast_future(df, horizon=10, poly_degree=2):
    """
    Performs multi-year forecasting for both annual rainfall and annual temperature.
    Returns a text summary along with a DataFrame containing the predictions.
    """
    def forecast_feature(feature, year):
        coeffs = np.polyfit(df['YEAR'], df[feature], poly_degree)
        poly = np.poly1d(coeffs)
        return poly(year)

    # Forecast for Annual Rainfall
    features_rain = ['YEAR']
    for col in ['MAM', 'JJAS', 'OND']:
        if col in df.columns:
            features_rain.append(col)
    
    X_rain = df[features_rain]
    y_rain = df['ANNUAL_rain']
    Xr_train, Xr_test, yr_train, yr_test = train_test_split(X_rain, y_rain, test_size=0.2, random_state=42)
    
    rf_rain = RandomForestRegressor(random_state=42)
    param_grid = {'n_estimators': [50, 100, 200], 'max_depth': [None, 5, 10]}
    grid_rain = GridSearchCV(rf_rain, param_grid, cv=3, scoring='neg_mean_squared_error')
    grid_rain.fit(Xr_train, yr_train)
    best_rf_rain = grid_rain.best_estimator_
    yr_pred = best_rf_rain.predict(Xr_test)
    mse_rain = mean_squared_error(yr_test, yr_pred)
    r2_rain = r2_score(yr_test, yr_pred)
    
    # Forecast for Annual Temperature
    features_temp = ['YEAR']
    for col in ['JAN-FEB', 'MAR-MAY', 'JUN-SEP', 'OCT-DEC']:
        if col in df.columns:
            features_temp.append(col)
    X_temp = df[features_temp]
    y_temp = df['ANNUAL_temp']
    Xt_train, Xt_test, yt_train, yt_test = train_test_split(X_temp, y_temp, test_size=0.2, random_state=42)
    
    rf_temp = RandomForestRegressor(random_state=42)
    grid_temp = GridSearchCV(rf_temp, param_grid, cv=3, scoring='neg_mean_squared_error')
    grid_temp.fit(Xt_train, yt_train)
    best_rf_temp = grid_temp.best_estimator_
    yt_pred = best_rf_temp.predict(Xt_test)
    mse_temp = mean_squared_error(yt_test, yt_pred)
    r2_temp = r2_score(yt_test, yt_pred)
    
    # Forecast Future Years
    future_years = list(range(int(df['YEAR'].max()) + 1, int(df['YEAR'].max()) + horizon + 1))
    predictions = []
    
    for year in future_years:
        # Rainfall features
        feat_rain = {'YEAR': year}
        for feat in features_rain:
            if feat != 'YEAR':
                try:
                    feat_rain[feat] = forecast_feature(feat, year)
                except Exception:
                    feat_rain[feat] = df[feat].mean()
        df_future_rain = pd.DataFrame([feat_rain])
        pred_rain = best_rf_rain.predict(df_future_rain)[0]

        # Temperature features
        feat_temp = {'YEAR': year}
        for feat in features_temp:
            if feat != 'YEAR':
                try:
                    feat_temp[feat] = forecast_feature(feat, year)
                except Exception:
                    feat_temp[feat] = df[feat].mean()
        df_future_temp = pd.DataFrame([feat_temp])
        pred_temp = best_rf_temp.predict(df_future_temp)[0]

        predictions.append({
            'YEAR': year, 
            'Predicted_Annual_Rainfall': pred_rain, 
            'Predicted_Annual_Temperature': pred_temp
        })
    pred_df = pd.DataFrame(predictions)
    
    result_text = f"Future Forecast (Next {horizon} Years):\n\n"
    result_text += f"Rainfall Model - Test MSE: {mse_rain:.2f}, R²: {r2_rain:.2f}\n"
    result_text += f"Temperature Model - Test MSE: {mse_temp:.2f}, R²: {r2_temp:.2f}\n\n"
    result_text += pred_df.to_string(index=False)
    
    return result_text, pred_df

def get_classification_report():
    """
    Trains a RandomForestClassifier on the full merged_df and returns the classification report.
    """
    threshold_rain = merged_df['ANNUAL_rain'].quantile(0.25)
    threshold_temp = merged_df['ANNUAL_temp'].quantile(0.75)
    merged_df['Risk'] = np.where(
        (merged_df['ANNUAL_rain'] < threshold_rain) & (merged_df['ANNUAL_temp'] > threshold_temp),
        'High Risk', 'Low Risk'
    )

    features = ['YEAR', 'ANNUAL_temp']
    for col in ['MAM', 'JJAS', 'OND']:
        if col in merged_df.columns:
            features.append(col)
    X = merged_df[features]
    y = merged_df['Risk']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = RandomForestClassifier(random_state=42)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    report = classification_report(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)
    result = f"Classification Report:\n{report}\nConfusion Matrix:\n{cm}"
    return result

def get_anomaly_info(subdivision):
    """
    Performs anomaly detection on the data for the selected subdivision and returns a string summary.
    """
    if 'SUBDIVISION' in merged_df.columns:
        df = merged_df[merged_df['SUBDIVISION'] == subdivision].copy()
    else:
        df = merged_df.copy()

    features = df[['ANNUAL_rain', 'ANNUAL_temp']]
    iso = IsolationForest(contamination=0.05, random_state=42)
    df['anomaly'] = iso.fit_predict(features)
    anomalies = df[df['anomaly'] == -1]

    if 'SUBDIVISION' in anomalies.columns:
        info = anomalies[['YEAR', 'SUBDIVISION', 'ANNUAL_rain', 'ANNUAL_temp']].to_string(index=False)
    else:
        info = anomalies[['YEAR', 'ANNUAL_rain', 'ANNUAL_temp']].to_string(index=False)
    
    return info

def generate_ai_recommendations(prompt):
    """
    Uses the Cohere API to generate AI recommendations based on the provided prompt.
    Replace "YOUR_API_KEY" with your actual Cohere API key.
    """
    import cohere
    API_KEY = "BOI7pYLeLilCROi5BUicZDejy9rk4ArpqsATrXOi"  # Replace with your actual Cohere API key
    client = cohere.ClientV2(API_KEY)
    response = client.chat(
         model="command-r-plus-08-2024",  # Adjust model as needed
         messages=[{"role": "user", "content": prompt}]
    )
    return response.message.content[0].text

def monthly_regression_forecast(df, month, data_type="rain"):
    """
    Given a dataframe, a month (e.g., 'JAN', 'FEB', etc.), and a data type ('rain' or 'temp'),
    this function searches for the corresponding column (e.g., 'JAN_rain' or 'JAN_temp').
    
    If found, it performs a simple linear regression (degree 1) of that column versus YEAR 
    and returns:
      - Forecasted value for next year,
      - Average value,
      - Minimum and maximum historical values.
    """
    month = month.upper()
    expected_col = f"{month}_{data_type}"  # e.g., 'JAN_rain' or 'JAN_temp'
    col_actual = None

    # Find the actual column name by comparing uppercase versions.
    for col in df.columns:
        if col.strip() == expected_col:
            col_actual = col
            break

    if col_actual is None:
        return None, None, None, None

    years = df['YEAR']
    values = df[col_actual]

    # Convert to numeric and handle errors (convert non-numeric values to NaN)
    values = pd.to_numeric(values, errors='coerce')

    # Remove rows where the value is NaN
    valid_indices = ~values.isna()
    years = years[valid_indices]
    values = values[valid_indices]

    if len(values) < 2:
        return None, None, None, None  # Not enough data for regression

    # Perform linear regression (degree 1)
    coeffs = np.polyfit(years, values, 1)
    poly = np.poly1d(coeffs)
    forecast = poly(df['YEAR'].max() + 1)
    avg_val = values.mean()
    min_val = values.min()
    max_val = values.max()

    return forecast, avg_val, min_val, max_val

# ----------------------------
# PyQt5 GUI Implementation
# ----------------------------
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QComboBox, QTabWidget, QTextEdit, QFileDialog, QMessageBox, QLineEdit, QListWidget, QListWidgetItem
)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar

class AnalysisTab(QWidget):
    def __init__(self, parent=None):
        super(AnalysisTab, self).__init__(parent)
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)

        # --- Control Panel (Top Buttons) ---
        control_panel = QHBoxLayout()
        lbl = QLabel("Select Subdivision:")
        control_panel.addWidget(lbl)

        # Populate subdivision options
        if 'SUBDIVISION' in merged_df.columns:
            sub_options = list(merged_df['SUBDIVISION'].unique())
        else:
            sub_options = ["National"]

        self.sub_combo = QComboBox()
        self.sub_combo.addItems(sub_options)
        control_panel.addWidget(self.sub_combo)

        btn_eda = QPushButton("Show EDA")
        btn_eda.clicked.connect(self.show_eda)
        control_panel.addWidget(btn_eda)

        btn_regression = QPushButton("Regression Forecast")
        btn_regression.clicked.connect(self.show_regression)
        control_panel.addWidget(btn_regression)

        btn_future = QPushButton("Future Forecast")
        btn_future.clicked.connect(self.show_future_forecast)
        control_panel.addWidget(btn_future)

        btn_classification = QPushButton("Classification Report")
        btn_classification.clicked.connect(self.show_classification)
        control_panel.addWidget(btn_classification)

        btn_anomaly = QPushButton("Anomaly Detection")
        btn_anomaly.clicked.connect(self.show_anomalies)
        control_panel.addWidget(btn_anomaly)

        btn_ai = QPushButton("Overall AI Recommendation")
        btn_ai.clicked.connect(self.show_ai_recommendations)
        control_panel.addWidget(btn_ai)

        main_layout.addLayout(control_panel)

        # --- Additional AI Query Panels ---

        # Water Resource Management Query
        water_layout = QHBoxLayout()
        water_label = QLabel("Water - Month (e.g., JAN):")
        water_layout.addWidget(water_label)
        self.waterMonthInput = QLineEdit()
        water_layout.addWidget(self.waterMonthInput)
        btn_water = QPushButton("Water Resource Recommendation")
        btn_water.clicked.connect(self.water_resource_recommendation)
        water_layout.addWidget(btn_water)
        main_layout.addLayout(water_layout)

        # Agricultural Practices Query
        agri_layout = QHBoxLayout()
        agri_label = QLabel("Agriculture - Month (e.g., FEB):")
        agri_layout.addWidget(agri_label)
        self.agriMonthInput = QLineEdit()
        agri_layout.addWidget(self.agriMonthInput)
        crop_label = QLabel("Select Crop(s):")
        agri_layout.addWidget(crop_label)
        self.crop_list = QListWidget()
        self.crop_list.setSelectionMode(QListWidget.MultiSelection)
        # Pre-populated crop options (can be adjusted)
        for crop in ["Wheat", "Rice", "Corn", "Soybean", "Cotton"]:
            item = QListWidgetItem(crop)
            self.crop_list.addItem(item)
        self.crop_list.setMaximumHeight(60)
        agri_layout.addWidget(self.crop_list)
        btn_agri = QPushButton("Agricultural Recommendation")
        btn_agri.clicked.connect(self.agriculture_recommendation)
        agri_layout.addWidget(btn_agri)
        main_layout.addLayout(agri_layout)

        # --- Plot Display Area ---
        self.plot_widget = QWidget()
        self.plot_layout = QVBoxLayout(self.plot_widget)
        self.plot_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(self.plot_widget, stretch=3)

        # --- Expanded Output Text Area for Results ---
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        # Give more vertical space to results:
        self.output_text.setMinimumHeight(250)
        main_layout.addWidget(self.output_text, stretch=2)

        self.current_canvas = None

    def clear_plot(self):
        if self.current_canvas:
            self.plot_layout.removeWidget(self.current_canvas)
            self.current_canvas.setParent(None)
            self.current_canvas = None

    def get_current_dataframe(self):
        sub = self.sub_combo.currentText()
        if 'SUBDIVISION' in merged_df.columns:
            df = merged_df[merged_df['SUBDIVISION'] == sub].copy()
        else:
            df = merged_df.copy()
        return df, sub

    def show_eda(self):
        self.clear_plot()
        df, sub = self.get_current_dataframe()
        fig = create_eda_figure(df, sub)
        self.current_canvas = FigureCanvas(fig)
        toolbar = NavigationToolbar(self.current_canvas, self)
        self.plot_layout.addWidget(toolbar)
        self.plot_layout.addWidget(self.current_canvas)
        self.output_text.clear()

    def show_regression(self):
        self.clear_plot()
        df, sub = self.get_current_dataframe()
        result = regression_forecast(df)
        self.output_text.setPlainText(result)

    def show_future_forecast(self):
        self.clear_plot()
        df, sub = self.get_current_dataframe()
        result_text, pred_df = forecast_future(df, horizon=10)
        self.output_text.setPlainText(result_text)

        # Create dual-axis plot
        fig, ax1 = plt.subplots(figsize=(8, 4))
        ax2 = ax1.twinx()
        ax1.plot(df['YEAR'], df['ANNUAL_rain'], 'b-o', label='Historical Rainfall')
        ax2.plot(df['YEAR'], df['ANNUAL_temp'], 'r-o', label='Historical Temperature')
        ax1.plot(pred_df['YEAR'], pred_df['Predicted_Annual_Rainfall'], 'b--s', label='Predicted Rainfall')
        ax2.plot(pred_df['YEAR'], pred_df['Predicted_Annual_Temperature'], 'r--s', label='Predicted Temperature')
        ax1.set_xlabel('Year')
        ax1.set_ylabel('Rainfall (mm)', color='b')
        ax2.set_ylabel('Temperature (°C)', color='r')
        plt.title("Future Forecasts")
        fig.legend(loc='upper left', bbox_to_anchor=(0.1, 0.9))
        fig.tight_layout(rect=[0, 0, 1, 0.95])
        
        self.current_canvas = FigureCanvas(fig)
        toolbar = NavigationToolbar(self.current_canvas, self)
        self.plot_layout.addWidget(toolbar)
        self.plot_layout.addWidget(self.current_canvas)

    def show_classification(self):
        self.clear_plot()
        result = get_classification_report()
        self.output_text.setPlainText(result)

    def show_anomalies(self):
        self.clear_plot()
        sub = self.sub_combo.currentText()
        info = get_anomaly_info(sub)
        self.output_text.setPlainText(f"Anomalies Detected for {sub}:\n{info}")

    def show_ai_recommendations(self):
        self.clear_plot()
        df, sub = self.get_current_dataframe()
        # Get forecast results for next 10 years
        forecast_text, pred_df = forecast_future(df, horizon=10)
    
        # Compute key historical results from last 10 years
        historical_data = df.sort_values(by='YEAR').tail(10)
        avg_rainfall = historical_data['ANNUAL_rain'].mean()
        avg_temp = historical_data['ANNUAL_temp'].mean()
        min_rainfall = historical_data['ANNUAL_rain'].min()
        max_rainfall = historical_data['ANNUAL_rain'].max()
        min_temp = historical_data['ANNUAL_temp'].min()
        max_temp = historical_data['ANNUAL_temp'].max()
    
        historical_results = (
            f"Historical Results for subdivision '{sub}' (last 10 years):\n"
            f" - Average Annual Rainfall: {avg_rainfall:.2f} mm\n"
            f" - Rainfall Range: {min_rainfall:.2f} mm to {max_rainfall:.2f} mm\n"
            f" - Average Annual Temperature: {avg_temp:.2f} °C\n"
            f" - Temperature Range: {min_temp:.2f} °C to {max_temp:.2f} °C"
        )
    
        prompt = (
            f"Given the following historical climate results for subdivision '{sub}':\n\n{historical_results}\n\n"
            f"and the following climate forecast information for the next 10 years for the same subdivision:\n\n{forecast_text}\n\n"
            "Please provide actionable sustainability recommendations for water resource management "
            "and agricultural planning, taking into account these past trends and forecasted changes "
            "in rainfall and temperature specific to this subdivision."
        )
    
        try:
            ai_recommendations = generate_ai_recommendations(prompt)
        except Exception as e:
            ai_recommendations = f"Error generating AI recommendations: {e}"
        self.output_text.setPlainText("Overall AI Recommendations:\n" + ai_recommendations)

    def water_resource_recommendation(self):
     """
    Uses the month entered by the user to compute regression forecasts (and historical statistics)
    for both rainfall and temperature. Then it builds a prompt for AI to generate 
    water resource management recommendations.
    """
     df, sub = self.get_current_dataframe()
     month = self.waterMonthInput.text().strip().upper()
    
     if not month:
        QMessageBox.warning(self, "Input Error", "Please enter a month (e.g., JAN, FEB, etc.)")
        return

    # Get Rainfall Forecast
     rain_forecast, rain_avg, rain_min, rain_max = monthly_regression_forecast(df, month, "rain")
     if rain_forecast is None:
        QMessageBox.warning(self, "Data Error", f"No rainfall data available for month '{month}'")
        return

    # Get Temperature Forecast
     temp_forecast, temp_avg, temp_min, temp_max = monthly_regression_forecast(df, month, "temp")
     if temp_forecast is None:
        QMessageBox.warning(self, "Data Error", f"No temperature data available for month '{month}'")
        return

     prompt = (
        f"For subdivision '{sub}', considering historical data for month '{month}':\n\n"
        f"Rainfall:\n"
        f" - Average: {rain_avg:.2f} mm\n"
        f" - Range: {rain_min:.2f} mm to {rain_max:.2f} mm\n"
        f" - Forecast for next year: {rain_forecast:.2f} mm\n\n"
        f"Temperature:\n"
        f" - Average: {temp_avg:.2f} °C\n"
        f" - Range: {temp_min:.2f} °C to {temp_max:.2f} °C\n"
        f" - Forecast for next year: {temp_forecast:.2f} °C\n\n"
        "Please provide detailed water resource management recommendations for the month, "
        "taking into account these rainfall and temperature trends."
    )

     try:
        recommendations = generate_ai_recommendations(prompt)
     except Exception as e:
        recommendations = f"Error generating AI recommendations: {e}"
    
     self.output_text.setPlainText("Water Resource Management Recommendations:\n" + recommendations)


    def agriculture_recommendation(self):
     """
    Uses the month and crop selection provided by the user to compute regression forecasts 
    (and historical statistics) for both rainfall and temperature. 
    Then it builds a prompt for AI to generate agriculture-specific recommendations.
    """
     df, sub = self.get_current_dataframe()
     month = self.agriMonthInput.text().strip().upper()
    
     if not month:
        QMessageBox.warning(self, "Input Error", "Please enter a month (e.g., JAN, FEB, etc.)")
        return

     selected_items = self.crop_list.selectedItems()
     if not selected_items:
        QMessageBox.warning(self, "Input Error", "Please select at least one crop")
        return

     crops = [item.text() for item in selected_items]

    # Get Rainfall Forecast
     rain_forecast, rain_avg, rain_min, rain_max = monthly_regression_forecast(df, month, "rain")
     if rain_forecast is None:
        QMessageBox.warning(self, "Data Error", f"No rainfall data available for month '{month}'")
        return

    # Get Temperature Forecast
     temp_forecast, temp_avg, temp_min, temp_max = monthly_regression_forecast(df, month, "temp")
     if temp_forecast is None:
        QMessageBox.warning(self, "Data Error", f"No temperature data available for month '{month}'")
        return

     prompt = (
        f"For subdivision '{sub}', considering historical data for month '{month}':\n\n"
        f"Rainfall:\n"
        f" - Average: {rain_avg:.2f} mm\n"
        f" - Range: {rain_min:.2f} mm to {rain_max:.2f} mm\n"
        f" - Forecast for next year: {rain_forecast:.2f} mm\n\n"
        f"Temperature:\n"
        f" - Average: {temp_avg:.2f} °C\n"
        f" - Range: {temp_min:.2f} °C to {temp_max:.2f} °C\n"
        f" - Forecast for next year: {temp_forecast:.2f} °C\n\n"
        f"Additionally, the following crop(s) are of interest: {', '.join(crops)}.\n\n"
        "Based on this information, please provide actionable recommendations for agricultural practices "
        "to optimize crop productivity and sustainability during the month specified."
    )

     try:
        recommendations = generate_ai_recommendations(prompt)
     except Exception as e:
        recommendations = f"Error generating AI recommendations: {e}"

     self.output_text.setPlainText("Agricultural Practices Recommendations:\n" + recommendations)


class ReportsTab(QWidget):
    def __init__(self, parent=None):
        super(ReportsTab, self).__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.save_btn = QPushButton("Save Report")
        self.save_btn.clicked.connect(self.save_report)
        layout.addWidget(self.save_btn)

        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        layout.addWidget(self.report_text)

    def save_report(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Save Report", "", "Text Files (*.txt)")
        if filename:
            try:
                with open(filename, 'w') as f:
                    f.write(self.report_text.toPlainText())
                QMessageBox.information(self, "Save Report", "Report saved successfully!")
            except Exception as e:
                QMessageBox.warning(self, "Save Report", f"Failed to save report:\n{e}")

class SettingsTab(QWidget):
    def __init__(self, parent=None):
        super(SettingsTab, self).__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        label = QLabel("Settings will be added here")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

class ClimateAnalysisApp(QMainWindow):
    def __init__(self):
        super(ClimateAnalysisApp, self).__init__()
        self.setWindowTitle("Climate Analysis GUI")
        self.resize(1000, 800)
        self.init_ui()

    def init_ui(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.analysis_tab = AnalysisTab(self)
        self.reports_tab = ReportsTab(self)
        self.settings_tab = SettingsTab(self)

        self.tabs.addTab(self.analysis_tab, "Analysis")
        self.tabs.addTab(self.reports_tab, "Reports")
        self.tabs.addTab(self.settings_tab, "Settings")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ClimateAnalysisApp()
    window.show()
    sys.exit(app.exec_())
